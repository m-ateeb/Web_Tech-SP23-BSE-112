const mongoose=require("mongoose");

let productschema=mongoose.Schema({
    title:String,
    description:String,
    price:Number,
})

let productModel=mongoose.model("Product",productschema);
module.exports=productModel;